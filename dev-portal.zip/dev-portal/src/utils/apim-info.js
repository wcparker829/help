export const resourceGroupName = "Will.Parker-rg";
export const subscriptionId = '30ff659c-157c-4ec6-833c-affbb07a0848'
export const serviceName = 'bentley-apim-test'
export const SAS = 'SharedAccessSignature integration&201909011410&B+F7QGA0/rwbAKBhpiXdu8WhO0agxlTu/GozcX3/+K5EYAf0TpDIXsMW9SiQxvsOu+JHuosGl3Wr/dZICu3HAA=='

export const headerName = 'Ocp-Apim-Subscription-Key';
export const subKey = '47a844606df74b46bdeee8824591f15e'