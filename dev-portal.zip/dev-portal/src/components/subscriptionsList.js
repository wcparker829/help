import React from "react"

class SubscriptionsList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true
        };
    }

    render() {
        return (
            <div className='subscriptions-list'>
                <h3>Your Subscriptions</h3>
                {this.props.subscriptions.map((subscription, index) => (
                    <div className='subscription' key={index}> 
                        <table>
                            <caption>
                                <h4 className='table-title'>{subscription.properties.displayName? subscription.properties.displayName : 'Unnamed Subscription'}</h4>
                                <button className='cancel-subscription'>Cancel</button>
                            </caption>
                            <tbody>
                                <tr>
                                    <td>Primary Key</td>
                                    <td><code id={subscription.name + '-primary'}>XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX</code></td>
                                    <td><button id={subscription.name + '-primary-button'} onClick={function() {
                                        const key = document.getElementById(subscription.name + '-primary')
                                        const button = document.getElementById(subscription.name + '-primary-button')
                                        if (button.innerText === 'Show') {
                                            button.innerText = 'Hide'
                                            key.innerText = subscription.properties.primaryKey
                                        } else {
                                            button.innerText = 'Show'
                                            key.innerText = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
                                        }
                                    }}>Show</button></td>
                                    <td><button>Regenerate</button></td>
                                </tr>
                                <tr>
                                    <td>Secondary Key</td>
                                    <td><code id={subscription.name + '-secondary'}>XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX</code></td>
                                    <td><button id={subscription.name + '-secondary-button'} onClick={function() {
                                        const key = document.getElementById(subscription.name + '-secondary')
                                        const button = document.getElementById(subscription.name + '-secondary-button')
                                        if (button.innerText === 'Show') {
                                            button.innerText = 'Hide'
                                            key.innerText = subscription.properties.secondaryKey
                                        } else {
                                            button.innerText = 'Show'
                                            key.innerText = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
                                        }
                                    }}>Show</button></td>
                                    <td><button>Regenerate</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                ))}
            </div>
        )
    }
}

export default SubscriptionsList