import React from 'react'

class Md extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
        }
    }

    render() {
        var text = this.props.text;
        text = text.split("\n");
        var textArr = [];
        for (var i = 0, j = 0; i < text.length; i++) {
            if (text[i]) {
                textArr[j] = text[i];
                j++;
            }
        }
        for (var k = 0; k < textArr.length; k++) {
            textArr[k] = textArr[k].replace("**", "<strong>").replace("**", "</strong>");
        };
        
        return (
            <div>
                {textArr.map((p, index) => (
                    <p key={index}>{p.search('<strong>') !== -1? <strong>{p.replace("<strong>", "").replace("</strong>", "")}</strong> : p }<br /></p>
                ))}
            </div>
        )
    }
}

export default Md