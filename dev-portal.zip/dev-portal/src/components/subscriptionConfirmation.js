import React from "react"
import { serviceName, resourceGroupName, subscriptionId, SAS } from "../utils/apim-info"

class SubscriptionConfirmation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            subscriptions: [],
            loading: true,
            subscriptionConfirmed: false,
        }
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        const that = this;

        const userId = nextProps.account.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users/${userId}/subscriptions?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.setRequestHeader("Authorization", SAS);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({
                subscriptions: data.value, 
                loading: false,
                subscriptionConfirmed: false
            });
        });
    }

    componentDidMount() {
        const that = this;
       
        const userId = this.props.account.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users/${userId}/subscriptions?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.setRequestHeader("Authorization", SAS);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({
                subscriptions: data.value, 
                loading: false,
                subscriptionConfirmed: false
            });
        });
    }

    handleSubmit() {
        const that = this;
        const userId = this.props.account.name;
        const year = new Date().getFullYear().toString()
        const month = new Date().getMonth().toString()
        const day = new Date().getDate().toString()
        const milli = new Date().getMilliseconds().toString()
        console.log()
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users/${userId}/subscriptions/${userId}${year}-${month}-${day}-${milli}?api-version=2019-01-01`;
        const displayName = `${this.props.account.properties.firstName} ${this.props.account.properties.lastName}'s ${this.props.product.properties.displayName} Subscription`
        const scope = `/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/products/${this.props.product.name}`

        const req = new XMLHttpRequest();
        req.open("PUT", url);
        req.setRequestHeader("Authorization", SAS);
        req.setRequestHeader('Content-type', 'application/json')
        req.send(JSON.stringify({
            "properties": {
                "displayName": displayName,
                "scope": scope,
                "state": "active"
            }
        }));
        req.addEventListener("load", function() {
            console.log(req.response)
            console.log(req.getAllResponseHeaders())
            //const data = JSON.parse(req.response);
            that.setState({
                subscriptions: that.state.subscriptions,
                loading: false,
                subscriptionConfirmed: true
            });
        });
    }

    render() {
        const account = this.props.account
        const product = this.props.product
        var flag = false;
        for (var i = 0; i < this.state.subscriptions.length; i++) {
            if (this.state.subscriptions[i].properties.scope.split("/")[10] === product.name) {
                flag = true;
            }
        }

        return (
            <div>
            {this.state.subscriptionConfirmed?
                <div className='SubscriptionConfirmation'> 
                    <p>Subscription Created</p>
                </div> :
            this.state.loading?
                <div></div> :
            flag? 
                <div className="SubscriptionConfirmation">
                    <p><b>{account.properties.firstName} {account.properties.lastName}</b> already has a subscription to <b>{product.properties.displayName}</b>.</p>
                </div> :
                <div className="SubscriptionConfirmation">
                    <p>Would you like to confirm a new subscription to <b>{product.properties.displayName}</b> for <b>{account.properties.firstName} {account.properties.lastName}</b>?</p>
                    <button className='subscription-button' onClick={this.handleSubmit}>Yes</button>
                    <button className='subscription-button' onClick={this.handleCancel}>No</button>
                </div> 
            }
            </div>
        )
    }
}

export default SubscriptionConfirmation