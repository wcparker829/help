import React from "react" 

class OperationDetails extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            operation: props.operation,
            selected: props.operation.properties.request,
            typeSelected: 'request'
        }

    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            operation: nextProps.operation,
            selected: nextProps.operation.properties.request,
            typeSelected: 'request'
        })
    }

    render() {
        const that = this;
        const operation = this.state.operation
        console.log(this.state)
        return (
            <div>
                <h2>{this.state.operation.properties.displayName}</h2>
                <div className='requests-and-responses'>
                    <button className='request-button' onClick={function() {
                        that.setState({
                            operation: operation,
                            selected: operation.properties.request,
                            typeSelected: 'request'
                        })
                    }}>Request</button>
                {operation.properties.responses.map((response, index) => (
                    <button className='response-button' key={index} onClick={function() {
                        that.setState({
                            operation: operation,
                            selected: response,
                            typeSelected: 'response'
                        })
                    }}>Response {response.statusCode}</button>
                ))}
                {that.state.typeSelected === 'response'?
                    <div className='response-box'>
                        <p>{this.state.selected.description}</p>

                    </div> :
                    <div className='request-box'>
                        <p><span className={operation.properties.method}>{operation.properties.method}</span> https://bentely-apim-test.devloper.azure-api.net{operation.urlTemplate}</p>
                    {operation.properties.templateParameters.length > 0? 
                        <div>
                            <h3>Parameters</h3>
                            <table className='parameter-table'>
                            {operation.properties.templateParameters.map((param, index) => (
                                <tr key={index}>
                                    <td className='parameter-table-data'>{param.name}</td>
                                    <td>{param.description}</td>
                                    <td>{param.type}</td>
                                </tr>
                            ))}
                            {this.state.selected? this.state.selected.queryParameters.map((param, index) => (
                                <tr key={index}>
                                    <td>{param.name}</td>
                                    <td>{param.description}</td>
                                    <td>{param.type}</td>
                                </tr>
                            )): <tr></tr>}
                            </table>
                        </div> : 
                        <div></div>
                    }
                    </div>}
                </div>
            </div>
        )
    }
}

export default OperationDetails