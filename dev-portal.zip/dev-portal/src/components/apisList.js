import React from "react"
import Md from "./md"
import { Link } from "gatsby"
import { serviceName, resourceGroupName, subscriptionId } from "../utils/apim-info"

class ApisList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            apis: [], 
            loading: true
        };
    }

    componentDidMount() {
        const page = this;

        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/apis?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            page.setState({apis: data.value, loading: false});
        });
    }

    render() {
        const that = this;
        return (
            <div>
                <section className='apis-list'>
                {this.state.apis.map((api, index) => (
                    <div className="api" key={index}>
                        <Link to='/api-details' state={{apis: that.state.apis, api: api}} key={index} className='details-link' >{api.properties.displayName}</Link>
                        {api.properties.description? <Md text={api.properties.description} /> : <p>No Description Available</p>}
                    </div>
                ))}
                </section>
            </div>
        )
    }
}

export default ApisList