import React from "react";
import { Link } from "gatsby";
import { serviceName, resourceGroupName, subscriptionId } from "../utils/apim-info"

class ProductList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            products: [],
            product: {},
            loading: true
        };
        this.handleProductClick = this.handleProductClick.bind(this);
    }


    componentDidMount() {
        const page = this;

        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/products?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response)
            page.setState({
                products: data.value, 
                product: data.value[0],
                loading: false})
        })
    }

    render() {
        if (this.state.loading)
            return null;
        return (
            <div>
                <section className='product-list'>
                    <h1>Products</h1>
                    {this.state.products.map((product, index) => (
                        <div className='product' key={index}>
                            <button onClick={this.handleProductClick} className='product-title' name={product.name}>{product.properties.displayName}</button>
                            <p className='product-description'>{product.properties.description}</p>
                        </div>
                    ))}
                </section>
                <aside className='product-api-list'>
                    <ProductApis product={this.state.product}/>
                </aside>
            </div>
        )
    }

    handleProductClick(e) {
        for (var i = 0; i < this.state.products.length; i++) {
            if (e.target.name === this.state.products[i].name) {
                this.setState({
                    product: this.state.products[i]
                });
                break;
            }
        }
    }
}

class ProductApis extends React.Component {
    constructor(props) {
        super(props);
        this.state = {apis: []};
    }

    componentWillMount() {
        const that = this;

        const productId = this.props.product.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/products/${productId}/apis?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({apis: data.value});
        });
    }

    componentWillReceiveProps(nextProps) {
        const that = this;
        const subscriptionId = "30ff659c-157c-4ec6-833c-affbb07a0848";
        const resourceGroupName = "Will.Parker-rg";
        const serviceName = "bentley-apim-test";
        const productId = nextProps.product.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/products/${productId}/apis?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({apis: data.value});
        });
    }

    render() {
        return (
            <div>
                <h3>APIs in {this.props.product.properties.displayName}</h3>
                <ul>
                {this.state.apis.length !== 0 && this.state.apis.map((api, index) => (
                    <li key={index} >{api.properties.displayName}</li>    
                ))}
                </ul>
                <br />
                <Link to='/account' className='subscribe-link' state={{ product: this.props.product}}>Subscribe</Link>
            </div>
        )
    }
}

export default ProductList