import React from "react"
import SubscriptionsList from "./subscriptionsList"
import { serviceName, resourceGroupName, subscriptionId, SAS } from "../utils/apim-info"

class AccountInfo extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            subscriptions: [],
            loading: true
        };
    }

    componentWillReceiveProps(nextProps) {
        const that = this;

        this.setState({
            subscriptions: [],
            loading: true
        })

        const userId = nextProps.account.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users/${userId}/subscriptions?api-version=2019-01-01`;

        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.setRequestHeader("Authorization", SAS)
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response)
            that.setState({
                subscriptions: data.value, 
                loading: false
            })
        })
    }

    componentDidMount() {
        const that = this;

        const subscriptionId = "30ff659c-157c-4ec6-833c-affbb07a0848";
        const resourceGroupName = "Will.Parker-rg";
        const serviceName = "bentley-apim-test";
        const userId = this.props.account.name;
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users/${userId}/subscriptions?api-version=2019-01-01`;
        const SAS = `SharedAccessSignature integration&201908151318&qXGhm4G3wvHIH1GYGbxyqbbmJQuH+v3JFx7ZAxOwqaUtR5vW3mU/W3fOqU59s5aaKe2F2oULCFIyviNI+ikoag==`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.setRequestHeader("Authorization", SAS)
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response)
            that.setState({
                subscriptions: data.value, 
                loading: false
            })
        })
    }
    
    render() {
        const account = this.props.account
        return (
            <div>
                <div>
                    <h3>Account Info</h3>
                    <table>
                        <tbody>
                            <tr>
                                <td>First Name:</td>
                                {this.state.loading? <td></td> : <td>{account.properties.firstName}</td>}
                            </tr>
                            <tr>
                                <td>Last Name:</td>
                                {this.state.loading? <td></td> : <td>{account.properties.lastName}</td>}
                            </tr>
                            <tr>
                                <td>Email:</td>
                                {this.state.loading? <td></td> : <td>{account.properties.email}</td>}
                            </tr>
                        </tbody>
                    </table>
                </div>
                {this.state.loading? <div></div> :  <SubscriptionsList subscriptions={this.state.subscriptions} />}
            </div>
        )
    }
}

export default AccountInfo