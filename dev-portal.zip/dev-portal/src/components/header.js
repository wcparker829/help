import React from "react"
import {Link} from "gatsby"

export default () => (
    <header>
        <div className='heading-container'>
            <div className='heading-element'>
                <h3><Link to='/' className='heading-title'>Page Title</Link></h3>
            </div>
            <div className='heading-element' id='nav-bar'>
                <Link to='/' className='heading-link' activeClassName='selected-heading-link'>Home</Link>
                <Link to='/testing' className='heading-link' activeClassName='selected-heading-link'>Testing</Link>
                <Link to='/apis' className='heading-link' activeClassName='selected-heading-link'>APIs</Link>
                <Link to='/products' className='heading-link' activeClassName='selected-heading-link'>Products</Link>
                <Link to='/account' className='heading-link' activeClassName='selected-heading-link'>Account</Link>
            </div>
        </div>     
    </header>
)