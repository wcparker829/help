import React from "react" 
import OperationDetails from "./operationDetails"
import { serviceName, resourceGroupName, subscriptionId, SAS } from "../utils/apim-info"

class OperationsList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            api: props.api,
            opertaions: [],
            operation: {},
            loading: true
        }
    }

    componentDidMount() {
        const that = this;

        const apiId = this.state.api.name
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/apis/${apiId}/operations?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({
                api: that.state.api,
                operations: data.value,
                operation: data.value[0],
                loading: false
            });
        });
    }

    componentWillReceiveProps(nextProps) {
        const that = this;

        const subscriptionId = "30ff659c-157c-4ec6-833c-affbb07a0848";
        const resourceGroupName = "Will.Parker-rg";
        const serviceName = "bentley-apim-test";
        const apiId = nextProps.api.name
        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/apis/${apiId}/operations?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response);
            that.setState({
                api: nextProps.api,
                operations: data.value,
                operation: data.value[0],
                loading: false
            });
        });

    }

    render() {
        const that = this;
        const isBrowser = typeof window !== 'undefined';
        
        return (
            <div>
                <aside className='operation-aside'>
                    <h2>{isBrowser? this.state.api.properties.displayName : ''}</h2>
                    {this.state.loading? <div></div> : 
                this.state.operations.map((operation, index) => (
                    <button key={index} className={'operation-button'} onClick={function() {
                        that.setState({
                            api: that.state.api,
                            operations: that.state.operations,
                            operation: operation,
                            loading: false
                        })
                    }}><span className={'method-name ' + operation.properties.method}>{operation.properties.method}</span><span className='op-name'>{operation.properties.displayName.replace(".", " ")}</span></button>
                ))}
                </aside>
                <article className='operation-main'>
                    {this.state.loading? <div></div> : 
                    <div>
                        <OperationDetails operation={this.state.operation} />
                    </div>
                    }

                </article>
            </div>
        )
    }
}

export default OperationsList