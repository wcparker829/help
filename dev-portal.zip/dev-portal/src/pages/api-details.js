import React from "react";
import Header from "../components/header"
import OperationsList from "../components/operationsList"

class ApiDetailsPage extends React.Component {
    constructor(props) {
        super(props)
        const isBrowser = typeof window !== 'undefined';
        isBrowser? this.state = {
            apis: props.location.state.apis,
            api: props.location.state.api,
            loading: true
        } : this.state = {
            apis: [],
            api: {},
            loading: true
        }
    }

    render() {
        const that = this;
        return (
            <div>
                <Header />
                <div className='container'>
                    <select id='api-selector' defaultValue={function() {
                        const select= document.getElementById('api-selector')
                        return select.value
                    }} onChange={function(value) {
                        const select = document.getElementById('api-selector') 
                        that.setState({
                            apis: that.state.apis,
                            api: that.state.apis[select.value],
                            loading: false
                        })
                    }}>
                        {this.state.apis.map((api, index) => (
                            <option key={index} value={index}>{api.properties.displayName}</option>
                        ))}
                    </select>
                    <OperationsList api={this.state.api} />
                </div>
            </div>
        )
    }
}

export default ApiDetailsPage;
