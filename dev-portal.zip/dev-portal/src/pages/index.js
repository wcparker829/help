import React from "react";
import Header from '../components/header';
import { UserManager } from "oidc-client";

class IndexPage extends React.Component {
    constructor(props) {
        super(props);
        
        // User Signin stuff
        const settings = {
            authority: 'https://qa-imsoidc.bentley.com',
            client_id: 'wills_test_client-dlq87o980fp1ov435ix95clsz',
            redirect_uri: 'http://localhost:8000/',
            response_type: 'code',
            scope: 'openid email profile'
        };
        const mgr = new UserManager(settings);
        mgr.events.addAccessTokenExpiring(function () {
            console.log("token expiring");
        });
        mgr.events.addAccessTokenExpired(function () {
            console.log("token expired");
        });
        mgr.events.addSilentRenewError(function (e) {
            console.log("silent renew error", e.message);
        });
        mgr.events.addUserLoaded(function (user) {
            console.log("user loaded", user);
            mgr.getUser().then(function(){
               console.log("getUser loaded user after userLoaded event fired"); 
            });
        });
        mgr.events.addUserUnloaded(function (e) {
            console.log("user unloaded");
        });
       
       
        this.state = {
            manager: mgr,
            loggedIn: document.URL.includes("?")
        };
        this.handleSignin = this.handleSignin.bind(this);
    }

    handleSignin() {
        this.state.manager.signinRedirect({state:'someState', redirect_uri: 'http://localhost:8000/'}).then(function() {
            console.log("signinRedirect done");
            this.setState({ manager: this.state.manager, loggedIn: true })
        }).catch(function(err) {
            console.log(err)
        });
    }

    render() {
        const that = this;
        this.state.loggedIn? this.state.manager.signinRedirectCallback(document.URL).then(function() {
            const user = that.state.manager.getUser();
            console.log(user);
        }) : console.log("not logged in yet")
        return (
            <div>
                <Header />
                <div className='container'>
                    <button onClick={this.handleSignin}>Sign in</button>
                </div>
            </div>
        )
    }
}

export default IndexPage