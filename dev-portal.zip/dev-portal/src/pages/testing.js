import React from "react";
import Header from "../components/header";
import { serviceName, resourceGroupName, subscriptionId, SAS, headerName, subKey } from "../utils/apim-info";

class TestingPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
            data: {},
            moreData: []
        };
    }

    componentDidMount() {
        const that = this;

        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/apis/management-api?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response)
            const req2 = new XMLHttpRequest();
            const url2 = `${data.properties.serviceUrl}/apis?api-version=2019-01-01`
            req2.open("GET", url2)
            req2.send()
            req2.addEventListener("load", function() {
                const moreData = JSON.parse(req2.response)
                that.setState({
                    loading: false,
                    data: data,
                    moreData: moreData.value
                });
            });
        });
    }

    render() {
        return (
            <div>
                <Header />
                <div className="container" >
                {this.state.loading? 
                    <div></div>
                :
                    console.log(this.state.data, '\n', this.state.moreData)
                }
                </div>
            </div>
        )
    }
}

export default TestingPage