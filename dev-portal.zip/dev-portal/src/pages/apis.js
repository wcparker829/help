import React from "react"
import Header from "../components/header"
import ApisList from "../components/apisList"

export default () => (
    <div>
        <Header />
        <div className='container'>
            <ApisList />
        </div>
    </div>
)