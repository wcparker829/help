import React from "react";
import Header from "../components/header";
import AccountInfo from "../components/accountInfo";
import SubscriptionConfirmation from "../components/subscriptionConfirmation";
import { serviceName, resourceGroupName, subscriptionId, SAS } from "../utils/apim-info";

class AccountPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            accounts: [],
            account: {},
            loading: true,
            accountSelected: false,
            confirmingSubscription: false
        };
    }

    componentDidMount() {
        const that = this;

        const url = `https://${serviceName}.management.azure-api.net/subscriptions/${subscriptionId}/resourceGroups/${resourceGroupName}/providers/Microsoft.ApiManagement/service/${serviceName}/users?api-version=2019-01-01`;
        
        const req = new XMLHttpRequest();
        req.open("GET", url);
        req.setRequestHeader("Authorization", SAS)
        req.send();
        req.addEventListener("load", function() {
            const data = JSON.parse(req.response)
            that.setState({
                accounts: data.value,
                account: that.state.account, 
                loading: false,
                accountSelected: that.state.accountSelected,
                confirmingSubscription: that.state.confirmingSubscription,
            })
        })
    }

    render() {
        const that = this;
        return (
            <div>
                <Header />
                <div className='container'>
                    {this.state.loading? 
                        <div></div>
                    :
                        (this.state.accountSelected? 
                            (this.state.confirmingSubscription? 
                                <div>
                                    <select id='account-select' defaultValue={that.state.account} onChange={
                                        function() {
                                            const select = document.getElementById('account-select')
                                            that.setState({
                                                accounts: that.state.accounts,
                                                account: that.state.accounts[select.value],
                                                loading: false,
                                                accountSelected: true,
                                                confirmingSubscription: true
                                            })                                
                                        }
                                    }>
                                        <option disabled={true} value='name-option'>Select an account</option>
                                        {this.state.accounts.map((account, index) => (
                                            <option key={index} value={index} >{account.name}</option>
                                        ))}
                                    </select>
                                    <div>
                                        <SubscriptionConfirmation account={this.state.account} product={this.props.location.state.product} />
                                        <AccountInfo account={this.state.account} />
                                    </div>
                                </div> 
                            :
                                // this.state.deletingSubscription??
                                <div>
                                    <select id='account-select' defaultValue={that.state.account} onChange={
                                        function() {
                                            const select = document.getElementById('account-select')
                                            that.setState({
                                                accounts: that.state.accounts,
                                                account: that.state.accounts[select.value],
                                                loading: false,
                                                accountSelected: true
                                            })    
                                        }}
                                    >
                                        <option disabled={true} value='name-option'>Select an account</option>
                                        {this.state.accounts.map((account, index) => (
                                            <option key={index} value={index} >{account.name}</option>
                                        ))}
                                    </select>
                                    <div>
                                        <AccountInfo account={this.state.account} />
                                    </div>
                                </div>
                            )
                        : 
                            <div>
                                <select id='account-select' defaultValue='name-option' onChange={
                                    that.props.location.state.product? 
                                        function() {
                                            const select = document.getElementById('account-select')
                                            that.setState({
                                                accounts: that.state.accounts,
                                                account: that.state.accounts[select.value],
                                                loading: false,
                                                accountSelected: true,
                                                confirmingSubscription: true
                                            })
                                        } 
                                    :
                                        function() {
                                            const select = document.getElementById('account-select')                    
                                            that.setState({
                                                accounts: that.state.accounts,
                                                account: that.state.accounts[select.value],
                                                loading: false,
                                                accountSelected: true,
                                                confirmingSubscription: false
                                            })
                                        }
                                    }
                                >
                                    <option disabled={true} value='name-option'>Select an account</option>
                                    {this.state.accounts.map((account, index) => (
                                        <option key={index} value={index} >{account.name}</option>
                                    ))}
                                </select>
                            </div>
                        )
                    }
                </div>
            </div>
        )
    }
}

export default AccountPage