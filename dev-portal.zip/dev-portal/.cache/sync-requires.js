const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-pages-account-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\account.js"))),
  "component---src-pages-api-details-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\api-details.js"))),
  "component---src-pages-apis-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\apis.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\index.js"))),
  "component---src-pages-products-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\products.js"))),
  "component---src-pages-testing-js": hot(preferDefault(require("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\testing.js")))
}

