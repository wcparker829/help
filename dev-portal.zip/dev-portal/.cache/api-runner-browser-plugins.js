module.exports = [{
      plugin: require('C:/Users/will.parker/OneDrive - Bentley Systems, Inc/Documents/dev-portal/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
