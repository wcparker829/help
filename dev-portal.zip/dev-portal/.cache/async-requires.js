// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---src-pages-account-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\account.js" /* webpackChunkName: "component---src-pages-account-js" */),
  "component---src-pages-api-details-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\api-details.js" /* webpackChunkName: "component---src-pages-api-details-js" */),
  "component---src-pages-apis-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\apis.js" /* webpackChunkName: "component---src-pages-apis-js" */),
  "component---src-pages-index-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\index.js" /* webpackChunkName: "component---src-pages-index-js" */),
  "component---src-pages-products-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\products.js" /* webpackChunkName: "component---src-pages-products-js" */),
  "component---src-pages-testing-js": () => import("C:\\Users\\will.parker\\OneDrive - Bentley Systems, Inc\\Documents\\dev-portal\\src\\pages\\testing.js" /* webpackChunkName: "component---src-pages-testing-js" */)
}

